package cadastrobd;

import cadastrobd.model.*;
import java.sql.SQLException;

public class CadastroBDTeste {
    public static void main(String[] args) throws Exception {
        try {
            PessoaFisica pf = new PessoaFisica(0, "Joao Silva", "Rua A", "SP", "SP", "11999999999", "joao@email.com", "12345678900");
            PessoaFisicaDAO pfDao = new PessoaFisicaDAO();
            pfDao.incluir(pf);

            pf.setCidade("São Paulo");
            pfDao.alterar(pf);

            for (PessoaFisica p : pfDao.getPessoas()) {
                p.exibir();
            }

            pfDao.excluir(pf.getId());

            PessoaJuridica pj = new PessoaJuridica(0, "Empresa Tiago", "Av. B", "RJ", "RJ", "2133334444", "contato@empresax.com", "12345678000199");
            PessoaJuridicaDAO pjDao = new PessoaJuridicaDAO();
            pjDao.incluir(pj);

            pj.setEstado("SP");
            pjDao.alterar(pj);

            for (PessoaJuridica p : pjDao.getPessoas()) {
                p.exibir();
            }

            pjDao.excluir(pj.getId());

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}