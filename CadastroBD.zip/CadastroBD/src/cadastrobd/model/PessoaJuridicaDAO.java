package cadastrobd.model;

import cadastrobd.model.util.ConectorBD;
import cadastrobd.model.util.SequenceManager;
import java.sql.*;
import java.util.ArrayList;
import java.sql.PreparedStatement;

public class PessoaJuridicaDAO {

    public void incluir(PessoaJuridica pj) throws Exception {
        Connection conn = ConectorBD.getConnection();

        try {
            int id = SequenceManager.getValue("seq_pessoa");
            pj.setId(id);

            // Inserir na tabela Pessoa
            String sqlPessoa = "INSERT INTO Pessoa (id, nome, logradouro, cidade, estado, telefone, email) " +
                               "VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement psPessoa = conn.prepareStatement(sqlPessoa);
            psPessoa.setInt(1, pj.getId());
            psPessoa.setString(2, pj.getNome());
            psPessoa.setString(3, pj.getLogradouro());
            psPessoa.setString(4, pj.getCidade());
            psPessoa.setString(5, pj.getEstado());
            psPessoa.setString(6, pj.getTelefone());
            psPessoa.setString(7, pj.getEmail());
            psPessoa.executeUpdate();
            psPessoa.close();

            // Inserir na tabela PessoaJuridica
            String sqlJuridica = "INSERT INTO PessoaJuridica (id, cnpj) VALUES (?, ?)";
            PreparedStatement psJuridica = conn.prepareStatement(sqlJuridica);
            psJuridica.setInt(1, pj.getId());
            psJuridica.setString(2, pj.getCnpj());
            psJuridica.executeUpdate();
            psJuridica.close();

        } finally {
            ConectorBD.close(conn);
        }
    }

    public void alterar(PessoaJuridica pj) throws SQLException {
        String sqlPessoa = "UPDATE Pessoa SET nome=?, logradouro=?, cidade=?, estado=?, telefone=?, email=? WHERE id=?";
        String sqlJuridica = "UPDATE PessoaJuridica SET cnpj=? WHERE id=?";
        try (Connection con = ConectorBD.getConnection()) {
            try (PreparedStatement ps = con.prepareStatement(sqlPessoa)) {
                ps.setString(1, pj.getNome());
                ps.setString(2, pj.getLogradouro());
                ps.setString(3, pj.getCidade());
                ps.setString(4, pj.getEstado());
                ps.setString(5, pj.getTelefone());
                ps.setString(6, pj.getEmail());
                ps.setInt(7, pj.getId());
                ps.executeUpdate();
            }
            try (PreparedStatement ps = con.prepareStatement(sqlJuridica)) {
                ps.setString(1, pj.getCnpj());
                ps.setInt(2, pj.getId());
                ps.executeUpdate();
            }
        }
    }

    public void excluir(int id) throws SQLException {
        try (Connection con = ConectorBD.getConnection()) {
            try (PreparedStatement ps = con.prepareStatement("DELETE FROM PessoaJuridica WHERE id=?")) {
                ps.setInt(1, id);
                ps.executeUpdate();
            }
            try (PreparedStatement ps = con.prepareStatement("DELETE FROM Pessoa WHERE id=?")) {
                ps.setInt(1, id);
                ps.executeUpdate();
            }
        }
    }

    public PessoaJuridica getPessoa(int id) throws SQLException {
        String sql = "SELECT * FROM Pessoa p JOIN PessoaJuridica pj ON p.id = pj.id WHERE p.id=?";
        try (Connection con = ConectorBD.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new PessoaJuridica(
                    rs.getInt("id"), rs.getString("nome"), rs.getString("logradouro"),
                    rs.getString("cidade"), rs.getString("estado"), rs.getString("telefone"),
                    rs.getString("email"), rs.getString("cnpj")
                );
            }
        }
        return null;
    }

    public ArrayList<PessoaJuridica> getPessoas() throws SQLException {
        ArrayList<PessoaJuridica> lista = new ArrayList<>();
        String sql = "SELECT * FROM Pessoa p JOIN PessoaJuridica pj ON p.id = pj.id";
        try (Connection con = ConectorBD.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(new PessoaJuridica(
                    rs.getInt("id"), rs.getString("nome"), rs.getString("logradouro"),
                    rs.getString("cidade"), rs.getString("estado"), rs.getString("telefone"),
                    rs.getString("email"), rs.getString("cnpj")
                ));
            }
        }
        return lista;
    }
}