package cadastrobd.model;

import cadastrobd.model.util.ConectorBD;
import java.sql.*;
import java.util.ArrayList;

public class PessoaJuridicaDAO {

    public void incluir(PessoaJuridica pj) throws SQLException {
        String sqlPessoa = "INSERT INTO Pessoa (nome, logradouro, cidade, estado, telefone, email) VALUES (?, ?, ?, ?, ?, ?)";
        String sqlJuridica = "INSERT INTO PessoaJuridica (id, cnpj) VALUES (?, ?)";
        try (Connection con = ConectorBD.getConnection()) {
            con.setAutoCommit(false);
            try (PreparedStatement ps = con.prepareStatement(sqlPessoa, Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, pj.getNome());
                ps.setString(2, pj.getLogradouro());
                ps.setString(3, pj.getCidade());
                ps.setString(4, pj.getEstado());
                ps.setString(5, pj.getTelefone());
                ps.setString(6, pj.getEmail());
                ps.executeUpdate();
                ResultSet rs = ps.getGeneratedKeys();
                if (rs.next()) pj.setId(rs.getInt(1));
            }
            try (PreparedStatement ps = con.prepareStatement(sqlJuridica)) {
                ps.setInt(1, pj.getId());
                ps.setString(2, pj.getCnpj());
                ps.executeUpdate();
            }
            con.commit();
        }
    }

    public void alterar(PessoaJuridica pj) throws SQLException {
        String sqlPessoa = "UPDATE Pessoa SET nome=?, logradouro=?, cidade=?, estado=?, telefone=?, email=? WHERE id=?";
        String sqlJuridica = "UPDATE PessoaJuridica SET cnpj=? WHERE id=?";
        try (Connection con = ConectorBD.getConnection()) {
            try (PreparedStatement ps = con.prepareStatement(sqlPessoa)) {
                ps.setString(1, pj.getNome());
                ps.setString(2, pj.getLogradouro());
                ps.setString(3, pj.getCidade());
                ps.setString(4, pj.getEstado());
                ps.setString(5, pj.getTelefone());
                ps.setString(6, pj.getEmail());
                ps.setInt(7, pj.getId());
                ps.executeUpdate();
            }
            try (PreparedStatement ps = con.prepareStatement(sqlJuridica)) {
                ps.setString(1, pj.getCnpj());
                ps.setInt(2, pj.getId());
                ps.executeUpdate();
            }
        }
    }

    public void excluir(int id) throws SQLException {
        try (Connection con = ConectorBD.getConnection()) {
            try (PreparedStatement ps = con.prepareStatement("DELETE FROM PessoaJuridica WHERE id=?")) {
                ps.setInt(1, id);
                ps.executeUpdate();
            }
            try (PreparedStatement ps = con.prepareStatement("DELETE FROM Pessoa WHERE id=?")) {
                ps.setInt(1, id);
                ps.executeUpdate();
            }
        }
    }

    public PessoaJuridica getPessoa(int id) throws SQLException {
        String sql = "SELECT * FROM Pessoa p JOIN PessoaJuridica pj ON p.id = pj.id WHERE p.id=?";
        try (Connection con = ConectorBD.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new PessoaJuridica(
                    rs.getInt("id"), rs.getString("nome"), rs.getString("logradouro"),
                    rs.getString("cidade"), rs.getString("estado"), rs.getString("telefone"),
                    rs.getString("email"), rs.getString("cnpj")
                );
            }
        }
        return null;
    }

    public ArrayList<PessoaJuridica> getPessoas() throws SQLException {
        ArrayList<PessoaJuridica> lista = new ArrayList<>();
        String sql = "SELECT * FROM Pessoa p JOIN PessoaJuridica pj ON p.id = pj.id";
        try (Connection con = ConectorBD.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(new PessoaJuridica(
                    rs.getInt("id"), rs.getString("nome"), rs.getString("logradouro"),
                    rs.getString("cidade"), rs.getString("estado"), rs.getString("telefone"),
                    rs.getString("email"), rs.getString("cnpj")
                ));
            }
        }
        return lista;
    }
}