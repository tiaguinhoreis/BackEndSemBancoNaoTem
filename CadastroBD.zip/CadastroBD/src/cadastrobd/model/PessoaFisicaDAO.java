package cadastrobd.model;

import cadastrobd.model.util.ConectorBD;
import java.sql.*;
import java.util.ArrayList;

public class PessoaFisicaDAO {

    public void incluir(PessoaFisica pf) throws SQLException {
        String sqlPessoa = "INSERT INTO Pessoa (nome, logradouro, cidade, estado, telefone, email) VALUES (?, ?, ?, ?, ?, ?)";
        String sqlFisica = "INSERT INTO PessoaFisica (id, cpf) VALUES (?, ?)";
        try (Connection con = ConectorBD.getConnection()) {
            con.setAutoCommit(false);
            try (PreparedStatement ps = con.prepareStatement(sqlPessoa, Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, pf.getNome());
                ps.setString(2, pf.getLogradouro());
                ps.setString(3, pf.getCidade());
                ps.setString(4, pf.getEstado());
                ps.setString(5, pf.getTelefone());
                ps.setString(6, pf.getEmail());
                ps.executeUpdate();
                ResultSet rs = ps.getGeneratedKeys();
                if (rs.next()) pf.setId(rs.getInt(1));
            }
            try (PreparedStatement ps = con.prepareStatement(sqlFisica)) {
                ps.setInt(1, pf.getId());
                ps.setString(2, pf.getCpf());
                ps.executeUpdate();
            }
            con.commit();
        }
    }

    public void alterar(PessoaFisica pf) throws SQLException {
        String sqlPessoa = "UPDATE Pessoa SET nome=?, logradouro=?, cidade=?, estado=?, telefone=?, email=? WHERE id=?";
        String sqlFisica = "UPDATE PessoaFisica SET cpf=? WHERE id=?";
        try (Connection con = ConectorBD.getConnection()) {
            try (PreparedStatement ps = con.prepareStatement(sqlPessoa)) {
                ps.setString(1, pf.getNome());
                ps.setString(2, pf.getLogradouro());
                ps.setString(3, pf.getCidade());
                ps.setString(4, pf.getEstado());
                ps.setString(5, pf.getTelefone());
                ps.setString(6, pf.getEmail());
                ps.setInt(7, pf.getId());
                ps.executeUpdate();
            }
            try (PreparedStatement ps = con.prepareStatement(sqlFisica)) {
                ps.setString(1, pf.getCpf());
                ps.setInt(2, pf.getId());
                ps.executeUpdate();
            }
        }
    }

    public void excluir(int id) throws SQLException {
        try (Connection con = ConectorBD.getConnection()) {
            try (PreparedStatement ps = con.prepareStatement("DELETE FROM PessoaFisica WHERE id=?")) {
                ps.setInt(1, id);
                ps.executeUpdate();
            }
            try (PreparedStatement ps = con.prepareStatement("DELETE FROM Pessoa WHERE id=?")) {
                ps.setInt(1, id);
                ps.executeUpdate();
            }
        }
    }

    public PessoaFisica getPessoa(int id) throws SQLException {
        String sql = "SELECT * FROM Pessoa p JOIN PessoaFisica pf ON p.id = pf.id WHERE p.id=?";
        try (Connection con = ConectorBD.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new PessoaFisica(
                    rs.getInt("id"), rs.getString("nome"), rs.getString("logradouro"),
                    rs.getString("cidade"), rs.getString("estado"), rs.getString("telefone"),
                    rs.getString("email"), rs.getString("cpf")
                );
            }
        }
        return null;
    }

    public ArrayList<PessoaFisica> getPessoas() throws SQLException {
        ArrayList<PessoaFisica> lista = new ArrayList<>();
        String sql = "SELECT * FROM Pessoa p JOIN PessoaFisica pf ON p.id = pf.id";
        try (Connection con = ConectorBD.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(new PessoaFisica(
                    rs.getInt("id"), rs.getString("nome"), rs.getString("logradouro"),
                    rs.getString("cidade"), rs.getString("estado"), rs.getString("telefone"),
                    rs.getString("email"), rs.getString("cpf")
                ));
            }
        }
        return lista;
    }
}